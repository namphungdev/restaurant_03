﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Restaurant.Models
{
    public class GioHang
    {        
        public SanPham SanPham { get; set; }
        public int SoLuong { get; set; }
     
    }
}
